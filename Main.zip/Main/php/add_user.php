<?php
//require the database and php funcitons
require_once 'db.php';
require_once 'functions.php';

//Execute the method of adding a user,
//and directly throw the entire $_POST individual sequence variable to the method.
$add_result = add_user($_POST['email'], $_POST['pw'], $_POST['n']);

if($add_result)
{
	//If true means the new addition is successful, print yes
	echo 'yes';
}
else
{
	//If null or false means failure
	echo 'no';
}

?>
