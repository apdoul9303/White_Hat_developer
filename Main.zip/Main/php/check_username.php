<?php
//require the database and php funcitons
require_once 'db.php';
require_once 'functions.php';

//Execute the method of checking user
$check = check_has_username($_POST['email']);

if($check)
{
	//If true, means the email has be registed
	echo 'no';
}
else
{
	//if null or false means this email can be registed 
	echo 'yes';
}

?>
