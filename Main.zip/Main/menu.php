
<?php include_once 'navTop.php'; ?>
<div class="jumbotron">
  <div class="container">
    <!-- 建立第一個 row 空間，裡面準備放格線系統 -->
    <div class="row">
      <!-- 在 xs 尺寸，佔12格，可參考 http://getbootstrap.com/css/#grid 說明-->
      <div class="col-xs-12">
        <!--網站標題-->
        <h1 class="text-center">White Hat Developer</h1><!--White Hat-->
				<h4 class="text-center"><span style="font-style:italic">
					Security Analysis and Improvement of PHP based Web Development Methods</span></h4>
        </ul>
      </div>
    </div>
  </div>
</div>
