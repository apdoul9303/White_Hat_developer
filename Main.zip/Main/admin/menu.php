<?php include_once 'navTop.php'; ?>
<div class="jumbotron">
  <div class="container">
    <div class="row">
      <div class="col-xs-12">
        <h1 class="text-center">White Hat Developer</h1><!--White Hat-->
				<h4 class="text-center"><span style="font-style:italic">
					Security Analysis and Improvement of PHP based Web Development Methods</span></h4>
        </ul>
      </div>
    </div>
  </div>
</div>
